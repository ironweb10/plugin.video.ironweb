import os
import sys
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath
from urllib.parse import urlencode, parse_qsl
from urllib.request import urlopen
from urllib.error import URLError, HTTPError
import re

HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')
DEFAULT_CHANNEL_ICON = ''  # Provide default channel icon path here

def list_menu():
    """
    Create the main menu in the Kodi interface.
    """
    # Set plugin category.
    xbmcplugin.setPluginCategory(HANDLE, 'Main Menu')
    # Set plugin content.
    xbmcplugin.setContent(HANDLE, 'videos')
    
    # Add TV option with logo
    list_item_tv = xbmcgui.ListItem(label='Canales de TV')
    list_item_tv.setArt({'icon': os.path.join(ICONS_DIR, 'tv_icon.png'),
                         'thumb': 'https://raw.githubusercontent.com/ironweb10/plugin.video.ironweb/main/tv_icon.png'})  # Set the logo here
    url_tv = get_url(action='list_channels', m3u_playlist_url='https://pastebin.com/raw/3SrRXyqu')
    is_folder_tv = True
    xbmcplugin.addDirectoryItem(HANDLE, url_tv, list_item_tv, is_folder_tv)

    # Add Movies option
    list_item_movies = xbmcgui.ListItem(label='Movies')
    list_item_movies.setArt({'icon': os.path.join(ICONS_DIR, 'movies_icon.png')})
    url_movies = get_url(action='list_movie_servers', m3u_playlist_url='https://github.com/ironweb10/plugin.video.ironweb/raw/main/peliculas.m3u')
    is_folder_movies = True
    xbmcplugin.addDirectoryItem(HANDLE, url_movies, list_item_movies, is_folder_movies)

    # Add YouTube option
    list_item_youtube = xbmcgui.ListItem(label='YouTube(Fixing)')
    list_item_youtube.setArt({'icon': os.path.join(ICONS_DIR, 'youtube_icon.png')})
    url_youtube = get_url(action='search_youtube')
    is_folder_youtube = True
    xbmcplugin.addDirectoryItem(HANDLE, url_youtube, list_item_youtube, is_folder_youtube)

    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(HANDLE)


def list_channels(m3u_playlist_url):
    """
    Create a list of channels from the provided M3U playlist URL.
    """
    try:
        response = urlopen(m3u_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            channels = []
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                if line.startswith('#EXTINF:-1'):
                    # Extract channel name and logo URL
                    match = re.search(r'tvg-logo="([^"]+)"', line)
                    if match:
                        logo_url = match.group(1)
                    else:
                        logo_url = None
                    channel_name = line.split(',')[-1].strip()
                    
                    # Extract channel URL
                    next_line = lines[i + 1].strip() if i + 1 < len(lines) else None
                    if next_line and next_line.startswith('http'):
                        channel_url = next_line
                        i += 1  # Move to the next line if the URL is on the next line
                    else:
                        channel_url = None
                    
                    # Add channel information to the list
                    if channel_name and channel_url:
                        channels.append({'name': channel_name, 'url': channel_url, 'logo': logo_url})
                i += 1
            
            # Display channels
            for channel in channels:
                list_item_channel = xbmcgui.ListItem(label=channel['name'])
                if channel['logo']:
                    list_item_channel.setArt({'icon': channel['logo']})
                else:
                    list_item_channel.setArt({'icon': DEFAULT_CHANNEL_ICON})  # Set a default icon if logo is not available
                list_item_channel.setInfo('video', {'title': channel['name']})
                list_item_channel.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(HANDLE, channel['url'], list_item_channel)
            
            # Finish creating a virtual folder.
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch channel list.')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch channel list. {}'.format(e))


def list_movie_servers(m3u_playlist_url):
    """
    List available movie servers.
    """
    try:
        response = urlopen(m3u_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            servers = []
            current_server = None
            for line in lines:
                line = line.strip()
                if line.startswith('#EXTINF:-1'):
                    match = re.search(r'tvg-logo="([^"]+)",(.+)', line)
                    if match:
                        logo_url = match.group(1)
                        server_name = match.group(2)
                        current_server = {'name': server_name, 'url': None, 'logo': logo_url}
                elif line.startswith('http'):
                    if current_server:
                        current_server['url'] = line
                        servers.append(current_server)
                        current_server = None
            
            # Display movie servers
            for server in servers:
                list_item_server = xbmcgui.ListItem(label=server['name'])
                list_item_server.setArt({'icon': server.get('logo', DEFAULT_CHANNEL_ICON)})  # Set logo
                list_item_server.setInfo('video', {'title': server['name']})  # Set video title
                xbmcplugin.addDirectoryItem(HANDLE, server['url'], list_item_server)
            
            # Finish creating a virtual folder.
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch movie servers list.')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch movie servers list. {}'.format(e))


def list_movies(m3u_playlist_url):
    """
    List movies available in the selected server.
    """
    try:
        response = urlopen(m3u_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            for line in lines:
                if line.startswith('#EXTINF:-1'):
                    match = re.search(r'tvg-logo="([^"]+)",\s*(.+)', line)
                    if match:
                        movie_name = match.group(2)
                        movie_url = lines[lines.index(line) + 1].strip()
                        list_item_movie = xbmcgui.ListItem(label=movie_name)
                        list_item_movie.setInfo('video', {'title': movie_name})  # Set video title
                        xbmcplugin.addDirectoryItem(HANDLE, movie_url, list_item_movie)
            
            # Finish creating a virtual folder.
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch movie list.')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch movie list. {}'.format(e))




def search_youtube():
    """
    Allow the user to input a search query for YouTube videos.
    """
    search_query = xbmcgui.Dialog().input('Enter search query')
    if search_query:
        videos = fetch_youtube_videos(search_query)
        if videos:
            for video in videos:
                list_item_video = xbmcgui.ListItem(label=video['title'])
                xbmcplugin.addDirectoryItem(HANDLE, video['url'], list_item_video)
            xbmcplugin.endOfDirectory(HANDLE)


def fetch_youtube_videos(search_query):
    """
    Fetch YouTube videos based on the search query.
    """
    api_url = f"http://riitube.rc24.xyz/wiimc/?q={search_query}"
    try:
        response = urlopen(api_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            videos = []
            for line in lines:
                if line.startswith('File'):
                    video_info = {}
                    parts = line.split('=')
                    video_info['url'] = parts[1]
                    video_info['title'] = parts[2]
                    videos.append(video_info)
            return videos
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch YouTube videos. HTTP Error: {}'.format(response.getcode()))
            return []
    except (URLError, HTTPError) as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch YouTube videos. {}'.format(e))
        return []



def get_url(**kwargs):
    """
    Create a URL with the given parameters.
    """
    return '{0}?{1}'.format(sys.argv[0], urlencode(kwargs))


def router(paramstring):
    """
    Router function that calls other functions based on the provided paramstring.
    """
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'list_channels':
            list_channels(params['m3u_playlist_url'])
        elif params['action'] == 'list_movies':
            list_movies(params['m3u_playlist_url'])
        elif params['action'] == 'search_youtube':
            search_youtube()
        elif params['action'] == 'play_movie':
            xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=params['url']))
        elif params['action'] == 'list_movie_servers':
            list_movie_servers(params['m3u_playlist_url'])
    else:
        list_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
