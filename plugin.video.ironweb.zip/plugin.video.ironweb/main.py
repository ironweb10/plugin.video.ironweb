import os
import sys
from xbmcvfs import translatePath
from urllib.parse import parse_qsl
import sys
import os
from xbmcaddon import Addon
import xbmcplugin
import xbmcgui


# Agrega la ruta completa al directorio de archivos al sys.padth
addon_dir = os.path.dirname(os.path.abspath(__file__))
files_dir = os.path.join(addon_dir, 'resources', 'files')
sys.path.append(files_dir)

# Importa el módulo channelsssssss xd 
from channels import list_channels

from movies import list_movie_servers, list_movies, get_url, search_movies
from resources.files.youtube import search_youtube, fetch_youtube_videos  

HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
DEFAULT_CHANNEL_ICON = ''

def list_menu():
    xbmcplugin.setPluginCategory(HANDLE, 'Main Menu')
    xbmcplugin.setContent(HANDLE, 'videos')
    
    list_item_tv = xbmcgui.ListItem(label='Canales de TV')
    list_item_tv.setArt({'icon': os.path.join(ICONS_DIR, 'tv_icon.png'),
                         'thumb': 'https://raw.githubusercontent.com/ironweb10/plugin.video.ironweb/main/images/tv_icon.png'})
    url_tv = get_url(action='list_channels', m3u_playlist_url='https://pastebin.com/raw/3SrRXyqu')
    is_folder_tv = True
    xbmcplugin.addDirectoryItem(HANDLE, url_tv, list_item_tv, is_folder_tv)

    list_item_movies = xbmcgui.ListItem(label='Películas')
    list_item_movies.setArt({'icon': os.path.join(ICONS_DIR, 'movies_icon.png')})
    url_movies = get_url(action='list_movie_servers')
    is_folder_movies = True
    xbmcplugin.addDirectoryItem(HANDLE, url_movies, list_item_movies, is_folder_movies)

    list_item_youtube = xbmcgui.ListItem(label='YouTube')
    list_item_youtube.setArt({'icon': os.path.join(ICONS_DIR, 'youtube_icon.png')})
    url_youtube = get_url(action='search_youtube')
    is_folder_youtube = True
    xbmcplugin.addDirectoryItem(HANDLE, url_youtube, list_item_youtube, is_folder_youtube)

    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'list_channels':
            list_channels(params['m3u_playlist_url'])
        elif params['action'] == 'list_movies':
            list_movies(params['m3u_playlist_url'])
        elif params['action'] == 'list_movie_servers':
            list_movie_servers()
        elif params['action'] == 'search_youtube':
            search_youtube()
        elif params['action'] == 'search_movies':
            search_movies()
    else:
        list_menu()

if __name__ == '__main__':
    router(sys.argv[2][1:])
