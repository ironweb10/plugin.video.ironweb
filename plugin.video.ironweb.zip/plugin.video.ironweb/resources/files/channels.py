import os
import xbmcgui
import xbmcplugin
from xbmcvfs import translatePath
from urllib.request import urlopen
from urllib.parse import urlencode
import re
import sys
from xbmcaddon import Addon

HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
DEFAULT_CHANNEL_ICON = ''

def list_channels(m3u_playlist_url):
    try:
        response = urlopen(m3u_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            channels = []
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                if line.startswith('#EXTINF:-1'):
                    match = re.search(r'tvg-logo="([^"]+)"', line)
                    if match:
                        logo_url = match.group(1)
                    else:
                        logo_url = None
                    channel_name = line.split(',')[-1].strip()
                    next_line = lines[i + 1].strip() if i + 1 < len(lines) else None
                    if next_line and next_line.startswith('http'):
                        channel_url = next_line
                        i += 1
                    else:
                        channel_url = None
                    if channel_name and channel_url:
                        channels.append({'name': channel_name, 'url': channel_url, 'logo': logo_url})
                i += 1
            for channel in channels:
                list_item_channel = xbmcgui.ListItem(label=channel['name'])
                if channel['logo']:
                    list_item_channel.setArt({'icon': channel['logo']})
                else:
                    list_item_channel.setArt({'icon': DEFAULT_CHANNEL_ICON})
                list_item_channel.setInfo('video', {'title': channel['name']})
                list_item_channel.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(HANDLE, channel['url'], list_item_channel)
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch channel list.')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch channel list. {}'.format(e))
