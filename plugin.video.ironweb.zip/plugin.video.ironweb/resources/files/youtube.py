import os
import xbmcgui
import xbmcplugin
from xbmcvfs import translatePath
from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import URLError, HTTPError
import json
import sys
from xbmcaddon import Addon

HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
API_KEY = "AIzaSyBfTw24MZHpsZQWNzHjK9EGPHPPIHLKO5k"
YOUTUBE_API_SEARCH_URL = "https://www.googleapis.com/youtube/v3/search"

def search_youtube():
    search_query = xbmcgui.Dialog().input('Pon lo que quieres buscar en youtube')
    if search_query:
        videos = fetch_youtube_videos(search_query)
        if videos:
            for video in videos:
                list_item_video = xbmcgui.ListItem(label=video['title'])
                list_item_video.setInfo('video', {'title': video['title']})
                list_item_video.setArt({'thumb': video['thumbnail']})  # Set thumbnail
                xbmcplugin.addDirectoryItem(HANDLE, video['url'], list_item_video, isFolder=False)  # Set isFolder to False for playable items
            xbmcplugin.endOfDirectory(HANDLE)


def fetch_youtube_videos(search_query):
    params = {
        "key": API_KEY,
        "part": "snippet",
        "q": search_query,
        "type": "video"
    }
    url = YOUTUBE_API_SEARCH_URL + "?" + urlencode(params)
    try:
        response = urlopen(url)
        if response.getcode() == 200:
            data = json.load(response)
            videos = []
            for item in data["items"]:
                video_info = {}
                video_info['title'] = item["snippet"]["title"]
                video_info['url'] = "plugin://plugin.video.youtube/play/?video_id=" + item["id"]["videoId"]
                # Choose higher resolution thumbnail (e.g., medium or high)
                video_info['thumbnail'] = item["snippet"]["thumbnails"]["high"]["url"]
                videos.append(video_info)
            return videos
        else:
            xbmcgui.Dialog().ok('Error', 'No se pudieron fechear los videos de YouTube. Error HTTP: {}'.format(response.getcode()))
            return []
    except URLError as e:
        xbmcgui.Dialog().ok('Error', 'No se pudieron fechear videos de YouTube. {}'.format(e))
        return []

