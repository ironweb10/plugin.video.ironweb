import os
import sys
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath
from urllib.parse import urlencode, parse_qsl
from urllib.request import urlopen
from urllib.error import URLError, HTTPError
import re

HANDLE = int(sys.argv[1])
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')

def list_movie_servers():
    """
    List available movie servers.
    """
    try:
        url_movies = get_url(action='list_movies', m3u_playlist_url='https://github.com/ironweb10/plugin.video.ironweb/raw/main/peliculas.m3u')
        list_item_movies = xbmcgui.ListItem(label='Servidores')
        list_item_movies.setArt({'icon': os.path.join(ICONS_DIR, 'server.png')})
        xbmcplugin.addDirectoryItem(HANDLE, url_movies, list_item_movies, isFolder=True)

        # Add option to search movies
        list_item_search = xbmcgui.ListItem(label='Buscar Películas')
        list_item_search.setArt({'icon': os.path.join(ICONS_DIR, 'buscar.png')})
        url_search = get_url(action='search_movies')
        xbmcplugin.addDirectoryItem(HANDLE, url_search, list_item_search, isFolder=True)

        # Finish creating a virtual folder.
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch movie servers list. {}'.format(e))


def list_movies(m3u_playlist_url):
    """
    List movies available in the selected server.
    """
    try:
        response = urlopen(m3u_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            for line in lines:
                if line.startswith('#EXTINF:-1'):
                    match = re.search(r'tvg-logo="([^"]+)"', line)
                    movie_logo = match.group(1) if match else None

                    match = re.search(r',(.+)', line)
                    if match:
                        movie_name = match.group(1)
                        movie_url = lines[lines.index(line) + 1].strip()

                        list_item_movie = xbmcgui.ListItem(label=movie_name)
                        if movie_logo:
                            list_item_movie.setArt({'icon': movie_logo})

                        xbmcplugin.addDirectoryItem(HANDLE, movie_url, list_item_movie, isFolder=False)

            # Finish creating the virtual folder.
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch movie list.')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch movie list. {}'.format(e))



def search_movies():
    """
    Allow the user to input a search query for movies.
    """
    search_query = xbmcgui.Dialog().input('Buscar Películas')
    if search_query:
        url_movies = f'https://api-xji1.onrender.com/api/movies.m3u?search={search_query}'
        list_movies(url_movies)


def get_url(**kwargs):
    """
    Create a URL with the given parameters.
    """
    return '{0}?{1}'.format(sys.argv[0], urlencode(kwargs))
