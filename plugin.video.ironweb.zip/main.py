import os
import sys
from urllib.parse import urlencode, parse_qsl
from urllib.request import urlopen
from urllib.error import URLError, HTTPError

import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from xbmcvfs import translatePath

# Get the plugin url in plugin:// notation.
URL = sys.argv[0]
# Get a plugin handle as an integer number.
HANDLE = int(sys.argv[1])
# Get addon base path
ADDON_PATH = translatePath(Addon().getAddonInfo('path'))
ICONS_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'icons')
FANART_DIR = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart')

def fetch_youtube_videos(search_query):
    api_url = f"http://riitube.rc24.xyz/wiimc/?q={search_query}"
    try:
        response = urlopen(api_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            videos = []
            for line in lines:
                if line.startswith('File'):
                    video_info = {}
                    parts = line.split('=')
                    video_info['url'] = parts[1]
                    video_info['title'] = parts[2]
                    videos.append(video_info)
            return videos
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch YouTube videos. HTTP Error: {}'.format(response.getcode()))
            return []
    except (URLError, HTTPError) as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch YouTube videos. {}'.format(e))
        return []

def fetch_tv_channels():
    M3U8_URL = "https://pastebin.com/raw/ntLuAQna"
    try:
        response = urlopen(M3U8_URL)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            channels = []
            current_channel = None
            for line in lines:
                line = line.strip()
                if line.startswith('#EXTINF:'):
                    parts = line.split('tvg-name="')
                    if len(parts) > 1:
                        current_channel = parts[1].split('"')[0]
                    logo_url_parts = line.split('tvg-logo="')
                    if len(logo_url_parts) > 1:
                        logo_url = logo_url_parts[1].split('"')[0]
                    else:
                        logo_url = None
                elif line and not line.startswith('#'):
                    channels.append({'title': current_channel, 'url': line, 'logo_url': logo_url})
            return channels
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch TV channels. HTTP Error: {}'.format(response.getcode()))
            return []
    except (URLError, HTTPError) as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch TV channels. {}'.format(e))
        return []

def get_url(**kwargs):
    return '{}?{}'.format(URL, urlencode(kwargs))

def list_menu():
    """
    Create the main menu in the Kodi interface.
    """
    # Set plugin category.
    xbmcplugin.setPluginCategory(HANDLE, 'Main Menu')
    # Set plugin content.
    xbmcplugin.setContent(HANDLE, 'videos')
    
    # Add TV option
    list_item_tv = xbmcgui.ListItem(label='TV')
    list_item_tv.setArt({'icon': os.path.join(ICONS_DIR, 'tv_icon.png')})
    url_tv = get_url(action='tv_menu')
    is_folder_tv = True
    xbmcplugin.addDirectoryItem(HANDLE, url_tv, list_item_tv, is_folder_tv)

    list_item_movies = xbmcgui.ListItem(label='Movies')
    list_item_movies.setArt({'icon': os.path.join(ICONS_DIR, 'movies_icon.png')})
    url_movies = get_url(action='list_movies', m3u_playlist_url='http://srregio.net/23ma/regioflix.m3u')
    is_folder_movies = True
    xbmcplugin.addDirectoryItem(HANDLE, url_movies, list_item_movies, is_folder_movies)

    # Add YouTube option
    list_item_youtube = xbmcgui.ListItem(label='YouTube(Fixing)')
    list_item_youtube.setArt({'icon': os.path.join(ICONS_DIR, 'youtube_icon.png')})
    url_youtube = get_url(action='search_youtube')
    is_folder_youtube = True
    xbmcplugin.addDirectoryItem(HANDLE, url_youtube, list_item_youtube, is_folder_youtube)

    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(HANDLE)


def list_movies(m3u_playlist_url):
    """
    Create a list of movies from the provided M3U playlist URL.
    """
    try:
        response = urlopen(m3u_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            movies = []
            title = None
            for line in lines:
                line = line.strip()
                if line.startswith('#EXTINF:-1'):
                    parts = line.split(',')
                    title = parts[-1].strip()
                elif line:
                    if title is not None:
                        movies.append({'title': title, 'url': line})
                        title = None
            
            # Display movies
            for movie in movies:
                list_item_movie = xbmcgui.ListItem(label=movie['title'])
                list_item_movie.setInfo('video', {'title': movie['title']})
                list_item_movie.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(HANDLE, movie['url'], list_item_movie)
            
            # Finish creating a virtual folder.
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch movie list.')
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch movie list. {}'.format(e))



def list_tv_menu():
    """
    Create a list of TV channels from the provided M3U8 playlist URL.
    """
    # Fetch M3U8 playlist from the URL
    m3u8_playlist_url = "https://pastebin.com/raw/ntLuAQna"
    try:
        response = urlopen(m3u8_playlist_url)
        if response.getcode() == 200:
            lines = response.read().decode('utf-8').split('\n')
            channels = []
            current_channel = None
            for line in lines:
                line = line.strip()
                if line.startswith('#EXTINF:'):
                    parts = line.split('tvg-name="')
                    if len(parts) > 1:
                        current_channel = parts[1].split('"')[0]
                    logo_url_parts = line.split('tvg-logo="')
                    if len(logo_url_parts) > 1:
                        logo_url = logo_url_parts[1].split('"')[0]
                    else:
                        logo_url = None
                elif line and not line.startswith('#'):
                    channels.append({'title': current_channel, 'url': line, 'logo_url': logo_url})
            
            # Display TV channels
            for channel in channels:
                list_item_channel = xbmcgui.ListItem(label=channel['title'])
                list_item_channel.setInfo('video', {'title': channel['title']})
                list_item_channel.setArt({'icon': channel['logo_url']})  # Set channel logo as icon
                xbmcplugin.addDirectoryItem(HANDLE, channel['url'], list_item_channel)
            
            # Finish creating a virtual folder.
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcgui.Dialog().ok('Error', 'Failed to fetch TV channels. HTTP Error: {}'.format(response.getcode()))
    except Exception as e:
        xbmcgui.Dialog().ok('Error', 'Failed to fetch TV channels. {}'.format(e))


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    if not params:
        # If the plugin is called from Kodi UI without any parameters,
        # display the main menu
        list_menu()
    elif params['action'] == 'play':
        # Play a video from a provided URL.
        play_video(params['video'])
    elif params['action'] == 'list_movies':
        # Display the list of movies
        list_movies("http://srregio.net/23ma/regioflix.m3u")  # Aquí pasamos la URL directamente
    elif params['action'] == 'tv_menu':
        # Display TV menu
        list_tv_menu()
    elif params['action'] == 'search_youtube':
        # Allow user to input search query for YouTube
        search_youtube()
    else:
        # If the provided paramstring does not contain a supported action
        # we raise an exception. This helps to catch coding errors,
        # e.g. typos in action names.
        raise ValueError(f'Invalid paramstring: {paramstring}!')

if __name__ == '__main__':
    router(sys.argv[2][1:])